package com.springboot.beginner.todopojo;

public class todo {

	private int id;
	private String tododetail;
	private String status;
	private String position;
	private String popularity;
	private String priority;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getPopularity() {
		return popularity;
	}
	public void setPopularity(String popularity) {
		this.popularity = popularity;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTododetail() {
		return tododetail;
	}
	public void setTododetail(String tododetail) {
		this.tododetail = tododetail;
	}
	public todo(int id, String tododetail, String status, String position, String popularity, String priority) {
		super();
		this.id = id;
		this.tododetail = tododetail;
		this.status = status;
		this.position = position;
		this.popularity = popularity;
		this.priority = priority;
	}
	public todo() {
		super();
	}	
}
