package com.springboot.beginner.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class todoentity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column
	private String tododetail;
	@Column
	private String status;
	@Column
	private String position;
	@Column
	private String popularity;
	@Column
	private String priority;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTododetail() {
		return tododetail;
	}
	public void setTododetail(String tododetail) {
		this.tododetail = tododetail;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getPopularity() {
		return popularity;
	}
	public void setPopularity(String popularity) {
		this.popularity = popularity;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public todoentity(int id, String tododetail, String status, String position, String popularity, String priority) {
		super();
		this.id = id;
		this.tododetail = tododetail;
		this.status = status;
		this.position = position;
		this.popularity = popularity;
		this.priority = priority;
	}
	public todoentity() {
		super();
	}	
}
