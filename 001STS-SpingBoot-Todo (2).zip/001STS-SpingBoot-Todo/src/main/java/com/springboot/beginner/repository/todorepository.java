package com.springboot.beginner.repository;

import java.util.Optional;

//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.beginner.entity.todoentity;

public interface todorepository extends JpaRepository<todoentity, Integer>{
	Optional<todoentity> findBytododetailContaining(String detail);
}
