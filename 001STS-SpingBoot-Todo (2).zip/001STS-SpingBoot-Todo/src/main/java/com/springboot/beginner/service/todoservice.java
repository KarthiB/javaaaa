package com.springboot.beginner.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.springboot.beginner.dao.tododao;
import com.springboot.beginner.todopojo.todo;

@Service
public class todoservice {
	@Autowired
	private tododao td;

	public void savetodo(todo todo) {
		td.savetodo(todo);
	}

	@Cacheable("todocache")
	public List<todo> getalltodos() {
		// TODO Auto-generated method stub
		/*
		 * try { System.out.println("************");
		 * System.out.println("Am Not todo'ing for 8 Seconds - Hoodi Baba");
		 * System.out.println("************"); Thread.sleep(8000); } catch (Exception
		 * ex) { System.out.println(ex.toString()); }
		 */
		return td.getAlltodos();
	}

	public todo gettodoById(int id) { // TODO Auto-generated method stub
		return td.getTodoById(id);
	}

	public List<todo> updatetodobyid(int id, todo todo) {
		return td.updatetodoById(id, todo);
	}

	public todo findbytododetail(String name) {
		return td.findBytododetail1(name);
	}

}
