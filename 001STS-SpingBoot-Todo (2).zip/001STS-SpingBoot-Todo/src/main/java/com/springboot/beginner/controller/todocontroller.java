package com.springboot.beginner.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.beginner.service.todoservice;
import com.springboot.beginner.todopojo.todo;

@RestController
public class todocontroller {
	
	@Autowired
	private todoservice ts;

	@RequestMapping("/welcome")
	public String welcome() {
		return "Welcome to Todo Services";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String saveTodo(@RequestBody todo todo) {		
		ts.savetodo(todo);
		System.out.println(todo.getTododetail());
		return "Its Added you know";
	}
	
	@RequestMapping(value="/all")
	public List<todo> getAlltodos(){
		return ts.getalltodos();
	}
	
	@GetMapping("/get/{myid}")
	public todo getTodoById(@PathVariable("myid")int id) {		
		return ts.gettodoById(id);
	}
	
	@PostMapping("/update/{myid}")
	public List<todo> updaterFriendById(@PathVariable("myid")int id, @RequestBody todo todo) {		
		return ts.updatetodobyid(id, todo);
	}
	
	@GetMapping("/find/{name}")
	public todo findbytododetail(@PathVariable("name") String detail) {
		return ts.findbytododetail(detail);
	}
}

