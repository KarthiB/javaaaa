package com.springboot.beginner.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springboot.beginner.entity.todoentity;
import com.springboot.beginner.repository.todorepository;
import com.springboot.beginner.todopojo.todo;

@Repository
public class tododao {

	@Autowired
	private todorepository tr;

	public void savetodo(todo todo) {
		// TODO Auto-generated method stub
		todoentity te = new todoentity();
		te.setTododetail(todo.getTododetail());
		te.setStatus(todo.getStatus());
		te.setPosition(todo.getPosition());
		te.setPopularity(todo.getPopularity());
		te.setPriority(todo.getPriority());
		tr.save(te);
	}

	public List<todo> getAlltodos() {

		List<todoentity> tes = tr.findAll();
		List<todo> ts = new ArrayList<todo>();
		for (todoentity te : tes) {
			todo tTemp = new todo();
			tTemp.setId(te.getId());
			tTemp.setTododetail(te.getTododetail());
			tTemp.setStatus(te.getStatus());
			tTemp.setPosition(te.getPosition());
			tTemp.setPopularity(te.getPopularity());
			tTemp.setPriority(te.getPriority());
			ts.add(tTemp);
		}
		return ts;
	}

	public todo getTodoById(int id) {
		todoentity te = tr.findById(id).get();
		todo tTemp = new todo();
		tTemp.setId(te.getId());
		tTemp.setTododetail(te.getTododetail());
		tTemp.setStatus(te.getStatus());
		tTemp.setPosition(te.getPosition());
		tTemp.setPopularity(te.getPopularity());
		tTemp.setPriority(te.getPriority());
		return tTemp;
	}

	/*
	 * public List<FriendEntity> deleteFriendById(int id) { // TODO Auto-generated
	 * method stub friendRepository.deleteById(id); return
	 * friendRepository.findAll(); }
	 */

	public List<todo> updatetodoById(int id, todo todo) {
		// TODO Auto-generated method stub
		todoentity te = new todoentity();
		te.setId(id);
		te.setTododetail(todo.getTododetail());
		te.setStatus(todo.getStatus());
		te.setPosition(todo.getPosition());
		te.setPopularity(todo.getPopularity());
		te.setPriority(todo.getPriority());
		tr.saveAndFlush(te);
		return getAlltodos();
	}

	public todo findBytododetail1(String name) {
		// TODO Auto-generated method stub
		System.out.println(name);
		todoentity te = tr.findBytododetailContaining(name).get();
		System.out.println(te.getStatus());
		todo tTemp = new todo();
		tTemp.setId(te.getId());
		tTemp.setTododetail(te.getTododetail());
		tTemp.setStatus(te.getStatus());
		tTemp.setPosition(te.getPosition());
		tTemp.setPopularity(te.getPopularity());
		tTemp.setPriority(te.getPriority());
		return tTemp;
	}

	/*
	 * public List<todo> updatetodoBydetail(String name) { // TODO Auto-generated
	 * method stub todoentity te = tr.findtodoBydetail(name).get(); todo tTemp = new
	 * todo(); tTemp.setId(te.getId()); tTemp.setTododetail(te.getTododetail());
	 * 
	 * te.setId(tTemp.getId()); te.setTododetail(tTemp.getTododetail());
	 * tr.saveAndFlush(te); return getAlltodos(); }
	 */
}
