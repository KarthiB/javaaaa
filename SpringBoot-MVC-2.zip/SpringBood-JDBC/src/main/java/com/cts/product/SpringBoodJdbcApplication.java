package com.cts.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringBoodJdbcApplication {

	public static void main(String[] args) {
		ApplicationContext ac = SpringApplication.run(SpringBoodJdbcApplication.class, args);
		ProductDaoImpl dao= ac.getBean(ProductDaoImpl.class);
		Product prod = new Product();
		prod.setDescription("description");
		prod.setId("228161");
		prod.setName("CTS");
		prod.setPrice((double) 225);
		
		//dao.saveProduct(prod);
		//System.out.println("Inserted");
		
		for(Product product:dao.getall())
		{
			System.out.println(product.getId());
			System.out.println(product.getName());
			System.out.println(product.getPrice());
			System.out.println(product.getDescription());
			System.out.println("----------");
		}
	}

}
