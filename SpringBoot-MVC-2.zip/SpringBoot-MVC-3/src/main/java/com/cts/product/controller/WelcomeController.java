package com.cts.product.controller;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.product.pojo.friend;
import com.cts.product.service.FriendService;

@RequestMapping("/api")
@RestController
public class WelcomeController {

	//FriendService fs = new FriendService();
	@Autowired
	private FriendService fs;
	
	@RequestMapping(value="/welcome", method=RequestMethod.GET)
	public String vaanga()
	{
		return "I am GETTING";
	}
	@RequestMapping(value="/welcome", method=RequestMethod.PUT)
	public String vaang1a()
	{
		return "I am PUTTING";
	}
	@RequestMapping(value="/welcome", method=RequestMethod.POST)
	public String vaang2a()
	{
		return "I am POSTING";
	}
	@RequestMapping(value="/welcome", method=RequestMethod.DELETE)
	public String vaang3a()
	{
		return "I am DELETING";
	}
	
	@GetMapping("/all")
	public List<friend> listfriends()
	{
		return fs.getAllFriends();
	}
	
	@RequestMapping(value="/get/{id}", method=RequestMethod.GET)	
	public friend getFriendById(@PathVariable String id)
	{
		return fs.getFriendByID(id);
	}
}
