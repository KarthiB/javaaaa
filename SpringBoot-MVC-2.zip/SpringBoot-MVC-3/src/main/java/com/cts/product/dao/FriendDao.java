package com.cts.product.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.product.pojo.friend;

@Repository
public class FriendDao {
	
	private List<friend> friends = new ArrayList<friend>(Arrays.asList(new friend("Girish",10,"10"),
			new friend("Vishnu",20,"20")));
	
	public List<friend> getAllFriends()
	{
		friend fr = new friend();
		//List<friend> friends = new ArrayList<>();
		fr.setAge(22);
		fr.setName("KB");
		fr.setId("30");
		friends.add(fr);
		friend fr1 = new friend();
		fr1.setAge(20);
		fr1.setName("Deepa");
		fr1.setId("40");
		friends.add(fr1);
		return friends;
	}

	public friend getFriendById(String id) {
		// TODO Auto-generated method stub
		return friends.stream().
				filter((f) -> f.getId().equals(id)).
				findFirst().get(); 
	}
}
