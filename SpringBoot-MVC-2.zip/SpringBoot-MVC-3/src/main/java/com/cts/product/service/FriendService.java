package com.cts.product.service;

import java.beans.Transient;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.product.dao.FriendDao;
import com.cts.product.pojo.friend;

@Service("fs")
public class FriendService {

	@Autowired
	private FriendDao friendDao;
	//FriendDao friendDao = new FriendDao();
	
	public List<friend> getAllFriends() {
		return friendDao.getAllFriends();
		
	}

	public friend getFriendByID(String id) {
		// TODO Auto-generated method stub
		return friendDao.getFriendById(id);
	}
}
