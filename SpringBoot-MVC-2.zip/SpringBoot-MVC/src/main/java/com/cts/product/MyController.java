package com.cts.product;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/s1")
	public void f1() {
		System.out.println("MyController F1 Method");
	}

	@RequestMapping("/s2")
	public void f2() {
		System.out.println("MyController F2 Method");
	}

	@RequestMapping("/s3")
	public String f3(Model model) {
		System.out.println("MyController F3 Method");
		String userName = "Ambreesh";
		model.addAttribute("uname", userName);
		return "one";
	}

	@RequestMapping("/s5")
	public ModelAndView f5() {
		System.out.println("MyController F5 Method");
		String userName = "Humphries";
		ModelAndView mav = new ModelAndView();
		mav.setViewName("one");
		mav.addObject("uname", userName);
		return mav;
	}
}
